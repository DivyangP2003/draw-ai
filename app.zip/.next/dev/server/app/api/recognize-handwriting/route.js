var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/recognize-handwriting/route.js")
R.c("server/chunks/node_modules_90358b02._.js")
R.c("server/chunks/[root-of-the-server]__4fc53ba3._.js")
R.c("server/chunks/_next-internal_server_app_api_recognize-handwriting_route_actions_0a10de71.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/recognize-handwriting/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/recognize-handwriting/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
