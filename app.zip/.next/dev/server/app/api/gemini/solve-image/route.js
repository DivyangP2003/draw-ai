var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/gemini/solve-image/route.js")
R.c("server/chunks/node_modules_9a8ba19a._.js")
R.c("server/chunks/[root-of-the-server]__97a0c001._.js")
R.c("server/chunks/_next-internal_server_app_api_gemini_solve-image_route_actions_1b19a9e8.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/gemini/solve-image/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/gemini/solve-image/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
