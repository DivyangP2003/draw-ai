var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/gemini/explain/route.js")
R.c("server/chunks/node_modules_aac72c4d._.js")
R.c("server/chunks/[root-of-the-server]__a417abae._.js")
R.c("server/chunks/_next-internal_server_app_api_gemini_explain_route_actions_30747340.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/gemini/explain/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/gemini/explain/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
