var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/recognize/route.js")
R.c("server/chunks/node_modules_0df2e7f2._.js")
R.c("server/chunks/[root-of-the-server]__d1931574._.js")
R.c("server/chunks/_next-internal_server_app_api_recognize_route_actions_fe38616d.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/recognize/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/recognize/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
