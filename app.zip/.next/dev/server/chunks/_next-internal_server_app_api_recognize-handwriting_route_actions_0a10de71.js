module.exports = [
"[project]/.next-internal/server/app/api/recognize-handwriting/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_recognize-handwriting_route_actions_0a10de71.js.map