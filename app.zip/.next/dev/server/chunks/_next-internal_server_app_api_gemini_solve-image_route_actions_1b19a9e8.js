module.exports = [
"[project]/.next-internal/server/app/api/gemini/solve-image/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_gemini_solve-image_route_actions_1b19a9e8.js.map