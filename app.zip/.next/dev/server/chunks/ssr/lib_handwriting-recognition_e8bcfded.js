module.exports = [
"[project]/lib/handwriting-recognition.js [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/lib_handwriting-recognition_07c4f214.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/lib/handwriting-recognition.js [app-ssr] (ecmascript)");
    });
});
}),
];