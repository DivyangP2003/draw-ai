module.exports = [
"[project]/components/drawing-canvas.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
/**
 * DrawingCanvas
 * Props:
 *  - currentTool: "pen" | "line" | "rectangle" | "circle" | "eraser" | "selection"
 *  - currentColor: "#RRGGBB"
 *  - strokeWidth: number (px)
 *  - onStateChange?: () => void
 *
 * Exposed ref API:
 *  - undo()
 *  - redo()
 *  - clear()
 *  - exportImage() -> dataURL
 *  - getCanvas() -> main canvas DOM node
 */ const DrawingCanvas = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ currentTool = "pen", currentColor = "#000000", strokeWidth = 2, onStateChange }, ref)=>{
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mainRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null) // final
    ;
    const overlayRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null) // preview, selection
    ;
    const [ctxMain, setCtxMain] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [ctxOverlay, setCtxOverlay] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // history as dataURL strings
    const historyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]);
    const historyStepRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(-1);
    const maxHistory = 50;
    // drawing state
    const drawingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    const startRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const selectionRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null) // {image: Image, sx, sy, sw, sh, dx, dy, dragging}
    ;
    const pointerIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // helpers for DPI and sizing
    const setupCanvases = ()=>{
        const container = containerRef.current;
        const main = mainRef.current;
        const overlay = overlayRef.current;
        if (!container || !main || !overlay) return;
        const rect = container.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        // set CSS sizes
        main.style.width = rect.width + "px";
        main.style.height = rect.height + "px";
        overlay.style.width = rect.width + "px";
        overlay.style.height = rect.height + "px";
        // set actual pixel sizes
        main.width = Math.round(rect.width * dpr);
        main.height = Math.round(rect.height * dpr);
        overlay.width = Math.round(rect.width * dpr);
        overlay.height = Math.round(rect.height * dpr);
        // scale contexts for drawing in CSS pixels
        const mainCtx = main.getContext("2d");
        const overlayCtx = overlay.getContext("2d");
        mainCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
        overlayCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
        // style defaults
        mainCtx.lineCap = "round";
        mainCtx.lineJoin = "round";
        overlayCtx.lineCap = "round";
        overlayCtx.lineJoin = "round";
        setCtxMain(mainCtx);
        setCtxOverlay(overlayCtx);
    };
    // initialize
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setupCanvases();
        const onResize = ()=>{
            // preserve image by redrawing from dataURL
            const main = mainRef.current;
            const data = exportImageDataURL();
            setupCanvases();
            if (data) {
                const img = new Image();
                img.onload = ()=>{
                    ctxMain && ctxMain.clearRect(0, 0, main.width, main.height);
                    const dpr = window.devicePixelRatio || 1;
                    const w = main.width / dpr;
                    const h = main.height / dpr;
                    ctxMain && ctxMain.drawImage(img, 0, 0, w, h);
                };
                img.src = data;
            }
        };
        window.addEventListener("resize", onResize);
        return ()=>window.removeEventListener("resize", onResize);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    // when ctx changes, ensure style matches props
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!ctxMain) return;
        ctxMain.lineWidth = strokeWidth;
        ctxMain.strokeStyle = currentColor;
        ctxMain.fillStyle = currentColor;
    }, [
        ctxMain,
        currentColor,
        strokeWidth
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!ctxOverlay) return;
        ctxOverlay.lineWidth = strokeWidth;
        ctxOverlay.strokeStyle = currentColor;
        ctxOverlay.fillStyle = currentColor;
    }, [
        ctxOverlay,
        currentColor,
        strokeWidth
    ]);
    // History helpers
    const pushHistory = ()=>{
        const url = exportImageDataURL();
        if (!url) return;
        const hist = historyRef.current;
        // trim any redo states
        const step = historyStepRef.current;
        if (step < hist.length - 1) hist.splice(step + 1);
        hist.push(url);
        // limit size
        if (hist.length > maxHistory) hist.shift();
        historyStepRef.current = hist.length - 1;
        onStateChange?.();
    };
    const exportImageDataURL = ()=>{
        const main = mainRef.current;
        if (!main) return null;
        // use CSS sized canvas snapshot by drawing to temporary canvas at CSS size (avoids DPR confusion)
        const rect = main.getBoundingClientRect();
        const temp = document.createElement("canvas");
        temp.width = Math.round(rect.width);
        temp.height = Math.round(rect.height);
        const tctx = temp.getContext("2d");
        // draw the main canvas scaled down from its backing store using drawImage
        tctx.drawImage(main, 0, 0, temp.width, temp.height);
        return temp.toDataURL("image/png");
    };
    const restoreFromDataURL = (dataURL)=>new Promise((resolve)=>{
            if (!dataURL) {
                resolve();
                return;
            }
            const img = new Image();
            img.onload = ()=>{
                const main = mainRef.current;
                const rect = main.getBoundingClientRect();
                ctxMain.clearRect(0, 0, rect.width, rect.height);
                ctxMain.drawImage(img, 0, 0, rect.width, rect.height);
                resolve();
            };
            img.src = dataURL;
        });
    const undo = async ()=>{
        const hist = historyRef.current;
        if (historyStepRef.current > 0) {
            historyStepRef.current -= 1;
            await restoreFromDataURL(hist[historyStepRef.current]);
            onStateChange?.();
        } else if (historyStepRef.current === 0) {
            // clear to blank
            const main = mainRef.current;
            if (main && ctxMain) {
                const rect = main.getBoundingClientRect();
                ctxMain.clearRect(0, 0, rect.width, rect.height);
                historyStepRef.current = -1;
                onStateChange?.();
            }
        }
    };
    const redo = async ()=>{
        const hist = historyRef.current;
        if (historyStepRef.current < hist.length - 1) {
            historyStepRef.current += 1;
            await restoreFromDataURL(hist[historyStepRef.current]);
            onStateChange?.();
        }
    };
    // expose ref API
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!ref) return;
        ref.current = {
            undo,
            redo,
            clear: ()=>{
                if (!ctxMain || !mainRef.current) return;
                const rect = mainRef.current.getBoundingClientRect();
                ctxMain.clearRect(0, 0, rect.width, rect.height);
                // push blank state
                pushHistory();
            },
            exportImage: ()=>exportImageDataURL(),
            getCanvas: ()=>mainRef.current
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        ctxMain,
        ctxOverlay
    ]);
    // pointer helpers
    const getPointerPos = (ev)=>{
        const rect = mainRef.current.getBoundingClientRect();
        // use clientX/clientY
        return {
            x: ev.clientX - rect.left,
            y: ev.clientY - rect.top
        };
    };
    const clearOverlay = ()=>{
        if (!ctxOverlay || !overlayRef.current) return;
        const r = overlayRef.current.getBoundingClientRect();
        ctxOverlay.clearRect(0, 0, r.width, r.height);
    };
    // commit shape from overlay to main (for line/rect/circle)
    const commitOverlayToMain = ()=>{
        const main = mainRef.current;
        if (!main || !ctxMain || !overlayRef.current) return;
        // draw overlay onto main (scale safe because both use CSS coords)
        ctxMain.drawImage(overlayRef.current, 0, 0, overlayRef.current.width / (window.devicePixelRatio || 1), overlayRef.current.height / (window.devicePixelRatio || 1));
        clearOverlay();
        pushHistory();
    };
    // selection helpers
    const captureSelection = (sx, sy, sw, sh)=>{
        if (!mainRef.current || !ctxMain) return null;
        const rect = mainRef.current.getBoundingClientRect();
        // create temp canvas at CSS size
        const tmp = document.createElement("canvas");
        tmp.width = Math.round(sw);
        tmp.height = Math.round(sh);
        const tctx = tmp.getContext("2d");
        // draw the selected portion from main canvas
        tctx.drawImage(mainRef.current, sx, sy, sw, sh, 0, 0, sw, sh);
        const img = new Image();
        img.src = tmp.toDataURL();
        return img;
    };
    // pointer event handlers (use pointer events for mouse + touch)
    const handlePointerDown = (ev)=>{
        // only primary pointer
        if (pointerIdRef.current && pointerIdRef.current !== ev.pointerId) return;
        pointerIdRef.current = ev.pointerId;
        ev.currentTarget.setPointerCapture(ev.pointerId);
        drawingRef.current = true;
        const pos = getPointerPos(ev);
        startRef.current = pos;
        clearOverlay();
        // pen start
        if (currentTool === "pen") {
            ctxMain.beginPath();
            ctxMain.lineWidth = strokeWidth;
            ctxMain.strokeStyle = currentColor;
            ctxMain.moveTo(pos.x, pos.y);
        } else if (currentTool === "eraser") {
            // immediate erase a dot
            ctxMain.clearRect(pos.x - strokeWidth / 2, pos.y - strokeWidth / 2, strokeWidth, strokeWidth);
        } else if (currentTool === "selection") {
        // start drawing selection rectangle on overlay
        // we'll draw live preview on overlay, on pointer up we'll capture
        // nothing else yet
        }
    };
    const handlePointerMove = (ev)=>{
        if (!drawingRef.current || ev.pointerId !== pointerIdRef.current) return;
        const pos = getPointerPos(ev);
        // pen
        if (currentTool === "pen") {
            ctxMain.lineTo(pos.x, pos.y);
            ctxMain.lineWidth = strokeWidth;
            ctxMain.strokeStyle = currentColor;
            ctxMain.stroke();
        } else if (currentTool === "eraser") {
            ctxMain.clearRect(pos.x - strokeWidth / 2, pos.y - strokeWidth / 2, strokeWidth, strokeWidth);
        } else if ([
            "line",
            "rectangle",
            "circle"
        ].includes(currentTool)) {
            // draw preview on overlay
            clearOverlay();
            ctxOverlay.lineWidth = strokeWidth;
            ctxOverlay.strokeStyle = currentColor;
            ctxOverlay.fillStyle = currentColor;
            if (currentTool === "line") {
                ctxOverlay.beginPath();
                ctxOverlay.moveTo(startRef.current.x, startRef.current.y);
                ctxOverlay.lineTo(pos.x, pos.y);
                ctxOverlay.stroke();
            } else if (currentTool === "rectangle") {
                const w = pos.x - startRef.current.x;
                const h = pos.y - startRef.current.y;
                ctxOverlay.strokeRect(startRef.current.x, startRef.current.y, w, h);
            } else if (currentTool === "circle") {
                const dx = pos.x - startRef.current.x;
                const dy = pos.y - startRef.current.y;
                const r = Math.sqrt(dx * dx + dy * dy);
                ctxOverlay.beginPath();
                ctxOverlay.arc(startRef.current.x, startRef.current.y, r, 0, Math.PI * 2);
                ctxOverlay.stroke();
            }
        } else if (currentTool === "selection") {
            // if we already have a captured selection and dragging
            if (selectionRef.current?.dragging) {
                // move selection image visually on overlay
                clearOverlay();
                const s = selectionRef.current;
                s.dx = pos.x - s.dxOffset;
                s.dy = pos.y - s.dyOffset;
                ctxOverlay.drawImage(s.image, s.dx, s.dy, s.sw, s.sh);
                // draw dashed border
                ctxOverlay.setLineDash([
                    6,
                    6
                ]);
                ctxOverlay.strokeRect(s.dx, s.dy, s.sw, s.sh);
                ctxOverlay.setLineDash([]);
            } else {
                // draw selection rectangle preview
                clearOverlay();
                ctxOverlay.setLineDash([
                    6,
                    6
                ]);
                const sx = Math.min(startRef.current.x, pos.x);
                const sy = Math.min(startRef.current.y, pos.y);
                const sw = Math.abs(pos.x - startRef.current.x);
                const sh = Math.abs(pos.y - startRef.current.y);
                ctxOverlay.strokeRect(sx, sy, sw, sh);
                ctxOverlay.setLineDash([]);
            }
        }
    };
    const handlePointerUp = async (ev)=>{
        if (!drawingRef.current || ev.pointerId !== pointerIdRef.current) return;
        ev.currentTarget.releasePointerCapture(ev.pointerId);
        drawingRef.current = false;
        pointerIdRef.current = null;
        const pos = getPointerPos(ev);
        if (currentTool === "pen") {
            ctxMain.closePath();
            pushHistory();
        } else if (currentTool === "eraser") {
            pushHistory();
        } else if ([
            "line",
            "rectangle",
            "circle"
        ].includes(currentTool)) {
            // commit overlay to main
            commitOverlayToMain();
        } else if (currentTool === "selection") {
            // if we were dragging an existing selection, commit it (draw onto main)
            if (selectionRef.current?.dragging) {
                const s = selectionRef.current;
                // draw selection image at new location to main
                ctxMain.clearRect(s.sx, s.sy, s.sw, s.sh); // cut original area (MS Paint moves)
                ctxMain.drawImage(s.image, s.dx, s.dy, s.sw, s.sh);
                selectionRef.current.dragging = false;
                selectionRef.current = null;
                clearOverlay();
                pushHistory();
            } else {
                // capture selection rectangle from startRef to pos
                const sx = Math.min(startRef.current.x, pos.x);
                const sy = Math.min(startRef.current.y, pos.y);
                const sw = Math.max(0, Math.abs(pos.x - startRef.current.x));
                const sh = Math.max(0, Math.abs(pos.y - startRef.current.y));
                if (sw > 0 && sh > 0) {
                    // grab image
                    const img = captureSelection(sx, sy, sw, sh);
                    // clear original area (cut)
                    ctxMain.clearRect(sx, sy, sw, sh);
                    selectionRef.current = {
                        image: img,
                        sx,
                        sy,
                        sw,
                        sh,
                        dx: sx,
                        dy: sy,
                        dragging: true,
                        dxOffset: pos.x - sx,
                        dyOffset: pos.y - sy
                    };
                    // draw selection image on overlay and dashed border so user can drag
                    clearOverlay();
                    img.onload = ()=>{
                        ctxOverlay.setLineDash([
                            6,
                            6
                        ]);
                        ctxOverlay.drawImage(img, sx, sy, sw, sh);
                        ctxOverlay.strokeRect(sx, sy, sw, sh);
                        ctxOverlay.setLineDash([]);
                    };
                }
            }
        }
        startRef.current = null;
    };
    // attach pointer listeners to overlay (on top)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const overlay = overlayRef.current;
        if (!overlay) return;
        overlay.addEventListener("pointerdown", handlePointerDown);
        overlay.addEventListener("pointermove", handlePointerMove);
        overlay.addEventListener("pointerup", handlePointerUp);
        overlay.addEventListener("pointercancel", handlePointerUp);
        return ()=>{
            overlay.removeEventListener("pointerdown", handlePointerDown);
            overlay.removeEventListener("pointermove", handlePointerMove);
            overlay.removeEventListener("pointerup", handlePointerUp);
            overlay.removeEventListener("pointercancel", handlePointerUp);
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        ctxMain,
        ctxOverlay,
        currentTool,
        currentColor,
        strokeWidth
    ]);
    // initialize blank history state on first paint
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // small timeout to ensure canvases setup
        const t = setTimeout(()=>{
            pushHistory();
        }, 50);
        return ()=>clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        ctxMain
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: "relative w-full h-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                ref: mainRef,
                className: "block w-full h-full bg-white",
                style: {
                    touchAction: "none",
                    display: "block"
                }
            }, void 0, false, {
                fileName: "[project]/components/drawing-canvas.jsx",
                lineNumber: 434,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                ref: overlayRef,
                className: "absolute inset-0 w-full h-full pointer-events-auto",
                style: {
                    top: 0,
                    left: 0,
                    touchAction: "none"
                }
            }, void 0, false, {
                fileName: "[project]/components/drawing-canvas.jsx",
                lineNumber: 440,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/drawing-canvas.jsx",
        lineNumber: 432,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
DrawingCanvas.displayName = "DrawingCanvas";
const __TURBOPACK__default__export__ = DrawingCanvas;
}),
"[project]/components/chat-interface.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ChatInterface
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
function ChatInterface({ messages, onSendMessage, isLoading }) {
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scrollToBottom = ()=>{
        messagesEndRef.current?.scrollIntoView({
            behavior: "smooth"
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        scrollToBottom();
    }, [
        messages
    ]);
    const handleSubmit = (e)=>{
        e.preventDefault();
        if (input.trim()) {
            onSendMessage(input);
            setInput("");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full bg-card rounded-xl border border-border shadow-sm overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 overflow-y-auto p-4 space-y-4",
                children: [
                    messages.map((message)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `flex ${message.type === "user" ? "justify-end" : "justify-start"}`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `max-w-xs lg:max-w-sm px-4 py-3 rounded-lg ${message.type === "user" ? "bg-blue-500 text-white rounded-br-none" : "bg-muted text-foreground rounded-bl-none"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm leading-relaxed",
                                        children: message.content
                                    }, void 0, false, {
                                        fileName: "[project]/components/chat-interface.jsx",
                                        lineNumber: 38,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs opacity-70 mt-1 block",
                                        children: message.timestamp.toLocaleTimeString([], {
                                            hour: "2-digit",
                                            minute: "2-digit"
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/components/chat-interface.jsx",
                                        lineNumber: 39,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/chat-interface.jsx",
                                lineNumber: 31,
                                columnNumber: 13
                            }, this)
                        }, message.id, false, {
                            fileName: "[project]/components/chat-interface.jsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this)),
                    isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-start",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-muted text-foreground px-4 py-3 rounded-lg rounded-bl-none",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                                    }, void 0, false, {
                                        fileName: "[project]/components/chat-interface.jsx",
                                        lineNumber: 52,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-2 bg-muted-foreground rounded-full animate-bounce delay-100"
                                    }, void 0, false, {
                                        fileName: "[project]/components/chat-interface.jsx",
                                        lineNumber: 53,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-2 h-2 bg-muted-foreground rounded-full animate-bounce delay-200"
                                    }, void 0, false, {
                                        fileName: "[project]/components/chat-interface.jsx",
                                        lineNumber: 54,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/chat-interface.jsx",
                                lineNumber: 51,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/chat-interface.jsx",
                            lineNumber: 50,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/chat-interface.jsx",
                        lineNumber: 49,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: messagesEndRef
                    }, void 0, false, {
                        fileName: "[project]/components/chat-interface.jsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/chat-interface.jsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-t border-border p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                    onSubmit: handleSubmit,
                    className: "flex gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: input,
                            onChange: (e)=>setInput(e.target.value),
                            placeholder: "Ask a question or describe your problem...",
                            className: "flex-1 px-4 py-2 rounded-lg bg-background border border-border focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm",
                            disabled: isLoading
                        }, void 0, false, {
                            fileName: "[project]/components/chat-interface.jsx",
                            lineNumber: 65,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "submit",
                            disabled: isLoading || !input.trim(),
                            className: "px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm font-medium",
                            children: "Send"
                        }, void 0, false, {
                            fileName: "[project]/components/chat-interface.jsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/chat-interface.jsx",
                    lineNumber: 64,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/chat-interface.jsx",
                lineNumber: 63,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/chat-interface.jsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/tool-bar.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ToolBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const PRESET_COLORS = [
    {
        name: "Black",
        value: "#000000"
    },
    {
        name: "White",
        value: "#FFFFFF"
    },
    {
        name: "Red",
        value: "#FF0000"
    },
    {
        name: "Blue",
        value: "#0000FF"
    },
    {
        name: "Green",
        value: "#00AA00"
    },
    {
        name: "Yellow",
        value: "#FFFF00"
    },
    {
        name: "Purple",
        value: "#AA00FF"
    },
    {
        name: "Orange",
        value: "#FF8800"
    }
];
const STROKE_WIDTHS = [
    1,
    2,
    3,
    5,
    8,
    12,
    16,
    20
];
function ToolBar({ currentTool, setCurrentTool, currentColor, setCurrentColor, strokeWidth, setStrokeWidth, canvasRef, onAnalyze }) {
    const handleClear = ()=>{
        if (canvasRef.current?.clear) canvasRef.current.clear();
    };
    const handleUndo = ()=>{
        if (canvasRef.current?.undo) canvasRef.current.undo();
    };
    const handleRedo = ()=>{
        if (canvasRef.current?.redo) canvasRef.current.redo();
    };
    const handleExport = ()=>{
        if (canvasRef.current?.exportImage) {
            const data = canvasRef.current.exportImage();
            // open in new tab for convenience
            if (data) {
                const w = window.open();
                w.document.write(`<img src="${data}" style="max-width:100%; height:auto;" />`);
            }
        }
    };
    const tools = [
        {
            id: "pen",
            label: "Pen",
            icon: "✏️"
        },
        {
            id: "line",
            label: "Line",
            icon: "📏"
        },
        {
            id: "rectangle",
            label: "Rectangle",
            icon: "▭"
        },
        {
            id: "circle",
            label: "Circle",
            icon: "○"
        },
        {
            id: "eraser",
            label: "Eraser",
            icon: "🧹"
        },
        {
            id: "selection",
            label: "Select",
            icon: "⬚"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-3 p-4 border-b border-slate-700 bg-slate-800",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 flex-wrap",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-semibold text-slate-400 uppercase",
                        children: "Tools"
                    }, void 0, false, {
                        fileName: "[project]/components/tool-bar.jsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-1 flex-wrap",
                        children: tools.map((tool)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setCurrentTool(tool.id),
                                className: `px-3 py-2 rounded text-sm font-medium transition-colors ${currentTool === tool.id ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-300 hover:bg-slate-600"}`,
                                title: tool.label,
                                children: tool.icon
                            }, tool.id, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/tool-bar.jsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/tool-bar.jsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 flex-wrap",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-semibold text-slate-400 uppercase",
                        children: "Colors"
                    }, void 0, false, {
                        fileName: "[project]/components/tool-bar.jsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 flex-wrap items-center",
                        children: [
                            PRESET_COLORS.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setCurrentColor(c.value),
                                    className: `w-8 h-8 rounded border-2 transition-all ${currentColor === c.value ? "border-blue-400 scale-110" : "border-slate-600"}`,
                                    style: {
                                        backgroundColor: c.value
                                    },
                                    title: c.name
                                }, c.value, false, {
                                    fileName: "[project]/components/tool-bar.jsx",
                                    lineNumber: 85,
                                    columnNumber: 13
                                }, this)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "color",
                                value: currentColor,
                                onChange: (e)=>setCurrentColor(e.target.value),
                                className: "w-8 h-8 p-0 border-2 rounded border-slate-600",
                                title: "Pick color"
                            }, void 0, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/tool-bar.jsx",
                        lineNumber: 83,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/tool-bar.jsx",
                lineNumber: 81,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-4 flex-wrap",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs font-semibold text-slate-400 uppercase",
                                children: "Thickness"
                            }, void 0, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 107,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: strokeWidth,
                                onChange: (e)=>setStrokeWidth(Number(e.target.value)),
                                className: "px-2 py-1 rounded bg-slate-700 text-slate-200 text-sm border border-slate-600 focus:outline-none focus:border-blue-500",
                                children: STROKE_WIDTHS.map((w)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: w,
                                        children: [
                                            w,
                                            "px"
                                        ]
                                    }, w, true, {
                                        fileName: "[project]/components/tool-bar.jsx",
                                        lineNumber: 114,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/tool-bar.jsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 ml-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleUndo,
                                className: "px-3 py-2 rounded bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors text-sm font-medium",
                                children: "↶ Undo"
                            }, void 0, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 122,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleRedo,
                                className: "px-3 py-2 rounded bg-slate-700 text-slate-300 hover:bg-slate-600 transition-colors text-sm font-medium",
                                children: "↷ Redo"
                            }, void 0, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 125,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleClear,
                                className: "px-3 py-2 rounded bg-red-900/50 text-red-300 hover:bg-red-900 transition-colors text-sm font-medium",
                                children: "Clear"
                            }, void 0, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 128,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleExport,
                                className: "px-3 py-2 rounded bg-slate-700 text-slate-200 hover:bg-slate-600 transition-colors text-sm font-medium",
                                children: "Export"
                            }, void 0, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 131,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onAnalyze,
                                className: "px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 transition-colors text-sm font-medium",
                                children: "Analyze"
                            }, void 0, false, {
                                fileName: "[project]/components/tool-bar.jsx",
                                lineNumber: 134,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/tool-bar.jsx",
                        lineNumber: 121,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/tool-bar.jsx",
                lineNumber: 105,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/tool-bar.jsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$drawing$2d$canvas$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/drawing-canvas.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$chat$2d$interface$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/chat-interface.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tool$2d$bar$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/tool-bar.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function Home() {
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 1,
            type: "ai",
            content: "Hello! I'm your Math Assistant. Draw an equation, diagram, or ask me a question, and I'll help you solve it!",
            timestamp: new Date()
        }
    ]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentTool, setCurrentTool] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("pen");
    const [currentColor, setCurrentColor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("#000000");
    const [strokeWidth, setStrokeWidth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(2);
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handleSendMessage = async (message)=>{
        if (!message.trim()) return;
        const userMessage = {
            id: messages.length + 1,
            type: "user",
            content: message,
            timestamp: new Date()
        };
        setMessages((prev)=>[
                ...prev,
                userMessage
            ]);
        setIsLoading(true);
        setTimeout(()=>{
            const aiMessage = {
                id: messages.length + 2,
                type: "ai",
                content: "I understand your question. Let me analyze this and provide a detailed solution.",
                timestamp: new Date()
            };
            setMessages((prev)=>[
                    ...prev,
                    aiMessage
                ]);
            setIsLoading(false);
        }, 1000);
    };
    const handleAnalyzeDrawing = async ()=>{
        if (!canvasRef.current) return;
        setIsLoading(true);
        const aiMessage = {
            id: messages.length + 1,
            type: "ai",
            content: "I can see your drawing! Let me analyze it and provide a solution.",
            timestamp: new Date()
        };
        setMessages((prev)=>[
                ...prev,
                aiMessage
            ]);
        setIsLoading(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-screen bg-slate-950 text-slate-100",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 flex flex-col overflow-hidden",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    className: "border-b border-slate-700 bg-slate-800 px-6 py-4 shadow-sm",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-10 h-10 rounded-lg bg-linear-to-br from-blue-500 to-purple-600 flex items-center justify-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-white font-bold text-lg",
                                            children: "∑"
                                        }, void 0, false, {
                                            fileName: "[project]/app/page.jsx",
                                            lineNumber: 72,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.jsx",
                                        lineNumber: 71,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                className: "text-2xl font-bold text-white",
                                                children: "Math Notes"
                                            }, void 0, false, {
                                                fileName: "[project]/app/page.jsx",
                                                lineNumber: 75,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-slate-400",
                                                children: "AI-Powered Problem Solver"
                                            }, void 0, false, {
                                                fileName: "[project]/app/page.jsx",
                                                lineNumber: 76,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/page.jsx",
                                        lineNumber: 74,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/page.jsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors text-sm font-medium text-slate-200",
                                    children: "New Session"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.jsx",
                                    lineNumber: 80,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/page.jsx",
                                lineNumber: 79,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/page.jsx",
                        lineNumber: 69,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/page.jsx",
                    lineNumber: 68,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 flex gap-4 overflow-hidden p-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 flex flex-col gap-4 min-w-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 bg-slate-800 rounded-xl border border-slate-700 shadow-sm overflow-hidden flex flex-col",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$tool$2d$bar$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        canvasRef: canvasRef,
                                        onAnalyze: handleAnalyzeDrawing
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.jsx",
                                        lineNumber: 92,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$drawing$2d$canvas$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        ref: canvasRef,
                                        currentTool: currentTool,
                                        currentColor: currentColor,
                                        strokeWidth: strokeWidth
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.jsx",
                                        lineNumber: 93,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/page.jsx",
                                lineNumber: 91,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/page.jsx",
                            lineNumber: 90,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full md:w-96 flex flex-col gap-4 min-w-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$chat$2d$interface$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                messages: messages,
                                onSendMessage: handleSendMessage,
                                isLoading: isLoading
                            }, void 0, false, {
                                fileName: "[project]/app/page.jsx",
                                lineNumber: 104,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/page.jsx",
                            lineNumber: 103,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/page.jsx",
                    lineNumber: 88,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.jsx",
            lineNumber: 66,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/page.jsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
];

//# sourceMappingURL=_d6568ecd._.js.map