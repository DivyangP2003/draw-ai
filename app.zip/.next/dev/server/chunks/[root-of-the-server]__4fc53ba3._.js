module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/api/recognize-handwriting/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$google$2f$generative$2d$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@google/generative-ai/dist/index.mjs [app-route] (ecmascript)");
;
const genAI = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$google$2f$generative$2d$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GoogleGenerativeAI"](process.env.GEMINI_API_KEY);
const HANDWRITING_PROMPT = `You are an expert in optical character recognition (OCR) and handwriting analysis. 
Carefully examine this handwritten content and perform these tasks:

1. Recognize and transcribe ALL handwritten text exactly as written
2. Identify the language(s) used
3. Assess clarity and legibility (0-100%)
4. Identify any mathematical symbols or special characters
5. Group related text together (e.g., equations, labels, titles)
6. Detect writing issues (misspellings, unclear characters)

Return a JSON response with this structure:
{
  "fullTranscription": "Complete transcribed text",
  "transcriptionConfidence": 0-100,
  "language": "detected language",
  "legibility": 0-100,
  "groups": [
    {
      "type": "text" | "equation" | "label" | "title" | "note",
      "content": "the content",
      "confidence": 0-100
    }
  ],
  "specialCharacters": ["list of math symbols or special chars found"],
  "issues": [
    {
      "type": "misspelling" | "unclear" | "incomplete",
      "description": "what is unclear",
      "suggestion": "suggested correction"
    }
  ],
  "metadata": {
    "writingStyle": "cursive" | "print" | "mixed",
    "writingSize": "small" | "medium" | "large",
    "spacing": "tight" | "normal" | "loose"
  }
}`;
async function POST(request) {
    try {
        const { image, region } = await request.json();
        if (!image) {
            return new Response(JSON.stringify({
                error: "No image provided"
            }), {
                status: 400,
                headers: {
                    "Content-Type": "application/json"
                }
            });
        }
        const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
        const imageBuffer = Buffer.from(base64Data, "base64");
        const model = genAI.getGenerativeModel({
            model: "gemini-2.5-flash"
        });
        const result = await model.generateContent({
            contents: [
                {
                    role: "user",
                    parts: [
                        {
                            inlineData: {
                                data: imageBuffer.toString("base64"),
                                mimeType: "image/png"
                            }
                        },
                        {
                            text: HANDWRITING_PROMPT
                        }
                    ]
                }
            ]
        });
        const responseText = await result.response.text();
        let recognitionData = {};
        try {
            const jsonMatch = responseText.match(/\{[\s\S]*\}/);
            recognitionData = jsonMatch ? JSON.parse(jsonMatch[0]) : {
                error: "Could not parse handwriting"
            };
        } catch (parseError) {
            console.error("JSON Parse Error:", parseError);
            recognitionData = {
                error: "Parsing failed",
                rawText: responseText,
                fullTranscription: responseText
            };
        }
        return new Response(JSON.stringify({
            recognition: recognitionData,
            timestamp: new Date().toISOString()
        }), {
            status: 200,
            headers: {
                "Content-Type": "application/json"
            }
        });
    } catch (error) {
        console.error("API Error:", error);
        return new Response(JSON.stringify({
            error: error.message || "Failed to recognize handwriting"
        }), {
            status: 500,
            headers: {
                "Content-Type": "application/json"
            }
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4fc53ba3._.js.map