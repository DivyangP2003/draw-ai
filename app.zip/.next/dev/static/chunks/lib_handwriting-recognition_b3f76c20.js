(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/handwriting-recognition.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "recognizeHandwriting",
    ()=>recognizeHandwriting,
    "terminateWorker",
    ()=>terminateWorker
]);
let isInitialized = false;
const characterPatterns = {
    A: {
        strokes: 3,
        height: "tall"
    },
    B: {
        strokes: 2,
        height: "tall"
    },
    C: {
        strokes: 1,
        height: "tall"
    },
    D: {
        strokes: 2,
        height: "tall"
    },
    E: {
        strokes: 3,
        height: "tall"
    },
    F: {
        strokes: 3,
        height: "tall"
    },
    G: {
        strokes: 1,
        height: "tall"
    },
    H: {
        strokes: 3,
        height: "tall"
    },
    I: {
        strokes: 1,
        height: "tall"
    },
    J: {
        strokes: 1,
        height: "tall"
    },
    K: {
        strokes: 3,
        height: "tall"
    },
    L: {
        strokes: 2,
        height: "tall"
    },
    M: {
        strokes: 1,
        height: "tall"
    },
    N: {
        strokes: 3,
        height: "tall"
    },
    O: {
        strokes: 1,
        height: "tall"
    },
    P: {
        strokes: 2,
        height: "tall"
    },
    Q: {
        strokes: 2,
        height: "tall"
    },
    R: {
        strokes: 2,
        height: "tall"
    },
    S: {
        strokes: 1,
        height: "tall"
    },
    T: {
        strokes: 2,
        height: "tall"
    },
    U: {
        strokes: 1,
        height: "tall"
    },
    V: {
        strokes: 2,
        height: "tall"
    },
    W: {
        strokes: 1,
        height: "tall"
    },
    X: {
        strokes: 2,
        height: "tall"
    },
    Y: {
        strokes: 3,
        height: "tall"
    },
    Z: {
        strokes: 3,
        height: "tall"
    },
    0: {
        strokes: 1,
        height: "medium"
    },
    1: {
        strokes: 1,
        height: "medium"
    },
    2: {
        strokes: 1,
        height: "medium"
    },
    3: {
        strokes: 1,
        height: "medium"
    },
    4: {
        strokes: 2,
        height: "medium"
    },
    5: {
        strokes: 1,
        height: "medium"
    },
    6: {
        strokes: 1,
        height: "medium"
    },
    7: {
        strokes: 2,
        height: "medium"
    },
    8: {
        strokes: 1,
        height: "medium"
    },
    9: {
        strokes: 1,
        height: "medium"
    }
};
const analyzeDrawing = (canvas)=>{
    const ctx = canvas.getContext("2d");
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    let minX = canvas.width, maxX = 0;
    let minY = canvas.height, maxY = 0;
    let pixelCount = 0;
    for(let i = 0; i < data.length; i += 4){
        const alpha = data[i + 3];
        if (alpha > 128) {
            const pixelIndex = i / 4;
            const x = pixelIndex % canvas.width;
            const y = Math.floor(pixelIndex / canvas.width);
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            pixelCount++;
        }
    }
    const width = maxX - minX;
    const height = maxY - minY;
    const aspectRatio = width > 0 ? height / width : 0;
    return {
        width,
        height,
        aspectRatio,
        pixelCount,
        bounds: {
            minX,
            maxX,
            minY,
            maxY
        }
    };
};
const recognizeHandwriting = async (canvas)=>{
    try {
        const features = analyzeDrawing(canvas);
        if (features.pixelCount === 0) {
            return "";
        }
        if (features.aspectRatio > 1.5) {
            return "I" // tall and thin = I
            ;
        } else if (features.aspectRatio > 1) {
            return "T" // tall = T or L
            ;
        } else if (features.aspectRatio < 0.5) {
            return "W" // wide = W or M
            ;
        } else if (features.width > features.height * 1.2) {
            return "O" // circular = O
            ;
        }
        return "";
    } catch (error) {
        console.error("[v0] Handwriting recognition error:", error);
        return "";
    }
};
const terminateWorker = async ()=>{
    isInitialized = false;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=lib_handwriting-recognition_b3f76c20.js.map