(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_fc41dd51._.js",
  "static/chunks/node_modules_katex_dist_katex_mjs_b8ab5b3b._.js",
  "static/chunks/node_modules_98da3713._.js",
  "static/chunks/_b631a12d._.js",
  "static/chunks/_6d9f2771._.css"
],
    source: "dynamic"
});
