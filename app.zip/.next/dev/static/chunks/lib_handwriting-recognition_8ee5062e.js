(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/handwriting-recognition.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/lib_handwriting-recognition_b3f76c20.js",
  "static/chunks/lib_handwriting-recognition_0679550d.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/lib/handwriting-recognition.js [app-client] (ecmascript)");
    });
});
}),
]);