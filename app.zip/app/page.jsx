"use client";

import { useState, useRef } from "react";
import DrawingCanvas from "@/components/drawing-canvas";
import ResultsPanel from "@/components/results-panel";
import Header from "@/components/header";

export default function Home() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  const handleAnalyze = async (imageData) => {
    setIsAnalyzing(true);
    setError(null);
    setResult(""); // start empty

    const controller = new AbortController();
    const timeout = setTimeout(() => {
      controller.abort(); // cancel request if it takes too long
      setIsAnalyzing(false);
      setError("Analysis timed out. Please try again.");
    }, 25000); // 25 seconds

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: imageData }),
        signal: controller.signal,
      });

      clearTimeout(timeout);

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to analyze image");
      }

      // Fake progressive streaming for UX
      const text = data.analysis || "";
      let idx = 0;
      setResult(""); // reset
      const interval = setInterval(() => {
        idx += 5; // show 5 chars at a time
        setResult(text.slice(0, idx));
        if (idx >= text.length) clearInterval(interval);
      }, 30); // 30ms per chunk
    } catch (err) {
      clearTimeout(timeout);
      setError(err.message);
      console.error("Analysis error:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground dark">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="flex flex-col">
            <h2 className="text-2xl font-bold mb-4">Draw Something</h2>
            <DrawingCanvas
              ref={canvasRef}
              onAnalyze={handleAnalyze}
              isAnalyzing={isAnalyzing}
            />
          </div>
          <div className="flex flex-col">
            <h2 className="text-2xl font-bold mb-4">AI Analysis</h2>
            <ResultsPanel
              result={result}
              error={error}
              isAnalyzing={isAnalyzing}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
