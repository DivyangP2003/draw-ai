"use client";

import { useRef, useState, useEffect } from "react";

const COLORS = [
  "#FFFFFF",
  "#FF0000",
  "#00FF00",
  "#0000FF",
  "#FFFF00",
  "#FF00FF",
  "#00FFFF",
  "#FFA500",
];
const SHAPES = ["free", "line", "rectangle", "circle", "eraser"];
const LINE_WIDTHS = [
  { label: "Thin", value: 2 },
  { label: "Medium", value: 4 },
  { label: "Thick", value: 6 },
  { label: "Bold", value: 8 },
  { label: "Extra Bold", value: 10 },
  { label: "Huge", value: 12 },
];
const LINE_TYPES = ["solid", "dashed", "filled"];
const MATH_SYMBOLS = [
  "+",
  "-",
  "×",
  "÷",
  "=",
  "≈",
  "≠",
  "<",
  ">",
  "≤",
  "≥",
  "√",
  "^",
  "π",
  "θ",
  "∞",
  "Σ",
  "∆",
  "∫",
  "∑",
  "∂",
  "→",
  "←",
  "↔",
  "⊕",
  "⊗",
  "∩",
  "∪",
  "⊂",
  "⊃",
  "∈",
  "∉",
  "%",
  "°",
  "∠",
  "|",
  "log",
  "ln",
  "sin",
  "cos",
  "tan",
];

export default function DrawingCanvas({ onAnalyze, isAnalyzing }) {
  const canvasRef = useRef(null);
  const [ctx, setCtx] = useState(null);
  const [color, setColor] = useState(COLORS[0]);
  const [lineWidth, setLineWidth] = useState(LINE_WIDTHS[1].value);
  const [lineType, setLineType] = useState("solid");
  const [shape, setShape] = useState("free");
  const [drawing, setDrawing] = useState(false);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [savedImage, setSavedImage] = useState(null);

  // Canvas setup
  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");
    context.lineCap = "round";
    context.lineJoin = "round";
    setCtx(context);

    const resizeCanvas = () => {
      const canvas = canvasRef.current;
      const context = canvas.getContext("2d");

      // Save current content as image
      const temp = canvas.toDataURL();
      const img = new Image();
      img.src = temp;

      // Save old size
      const oldWidth = canvas.width;
      const oldHeight = canvas.height;

      // Set new size
      const newWidth = window.innerWidth * 0.75;
      const newHeight = window.innerHeight;

      canvas.width = newWidth;
      canvas.height = newHeight;

      img.onload = () => {
        // Scale image to new canvas size
        context.drawImage(
          img,
          0,
          0,
          oldWidth,
          oldHeight,
          0,
          0,
          newWidth,
          newHeight
        );
      };
    };

    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();
    return () => window.removeEventListener("resize", resizeCanvas);
  }, []);

  const getPos = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const scaleX = canvasRef.current.width / rect.width;
    const scaleY = canvasRef.current.height / rect.height;
    let x, y;
    if (e.touches) {
      x = (e.touches[0].clientX - rect.left) * scaleX;
      y = (e.touches[0].clientY - rect.top) * scaleY;
    } else {
      x = (e.clientX - rect.left) * scaleX;
      y = (e.clientY - rect.top) * scaleY;
    }
    return { x, y };
  };

  // Start drawing
  const startDrawing = (e) => {
    if (!ctx) return;
    const pos = getPos(e);
    setStartPos(pos);
    setDrawing(true);

    ctx.beginPath();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    if (shape === "eraser") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.lineWidth = lineWidth * 2;
    } else {
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
      ctx.fillStyle = color;
      ctx.setLineDash(lineType === "dashed" ? [10, 5] : []);
    }

    if (shape === "free" || shape === "eraser") {
      ctx.moveTo(pos.x, pos.y);
    }

    if (["line", "rectangle", "circle"].includes(shape)) {
      setSavedImage(
        ctx.getImageData(
          0,
          0,
          canvasRef.current.width,
          canvasRef.current.height
        )
      );
    }
  };

  // Drawing
  const draw = (e) => {
    if (!drawing || !ctx) return;
    const pos = getPos(e);

    if (shape === "free" || shape === "eraser") {
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
    } else if (
      shape === "line" ||
      shape === "rectangle" ||
      shape === "circle"
    ) {
      if (savedImage) ctx.putImageData(savedImage, 0, 0);
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = lineWidth;
      ctx.setLineDash(lineType === "dashed" ? [10, 5] : []);

      if (shape === "line") {
        if (lineType === "filled") ctx.stroke(); // "filled" ignored for line
        ctx.moveTo(startPos.x, startPos.y);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
      } else if (shape === "rectangle") {
        if (lineType === "filled")
          ctx.fillRect(
            startPos.x,
            startPos.y,
            pos.x - startPos.x,
            pos.y - startPos.y
          );
        else
          ctx.strokeRect(
            startPos.x,
            startPos.y,
            pos.x - startPos.x,
            pos.y - startPos.y
          );
      } else if (shape === "circle") {
        const radius = Math.sqrt(
          Math.pow(pos.x - startPos.x, 2) + Math.pow(pos.y - startPos.y, 2)
        );
        ctx.arc(startPos.x, startPos.y, radius, 0, 2 * Math.PI);
        if (lineType === "filled") ctx.fill();
        else ctx.stroke();
      }
    }
  };

  const stopDrawing = () => {
    setDrawing(false);
  };

  const handleAnalyzeClick = () => {
    const imageData = canvasRef.current.toDataURL("image/png");
    onAnalyze(imageData);
  };

  const handleClear = () => {
    if (!ctx) return;
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
  };

  // Drag math symbols
  const handleDropSymbol = (symbol, e) => {
    if (!ctx) return;
    const pos = getPos(e);
    ctx.fillStyle = color;
    ctx.font = `${lineWidth * 7}px Arial`;
    ctx.fillText(symbol, pos.x, pos.y);
  };

  return (
    <div className="flex flex-col w-full h-full">
      {/* Toolbar */}
      <div className="flex items-center gap-2 p-2 bg-gray-100 dark:bg-gray-900 border-b border-gray-300 dark:border-gray-700 flex-wrap">
        {COLORS.map((c) => (
          <button
            key={c}
            onClick={() => setColor(c)}
            className={`w-8 h-8 rounded-full border-2 ${
              color === c
                ? "border-black dark:border-white"
                : "border-gray-300 dark:border-gray-600"
            }`}
            style={{ backgroundColor: c }}
          />
        ))}

        {SHAPES.map((s) => (
          <button
            key={s}
            onClick={() => setShape(s)}
            className={`px-2 py-1 rounded border ${
              shape === s
                ? "bg-blue-500 text-white"
                : "bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200"
            }`}
          >
            {s}
          </button>
        ))}

        {/* Line Width */}
        <select
          value={lineWidth}
          onChange={(e) => setLineWidth(parseInt(e.target.value))}
          className="px-2 py-1 border rounded bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200"
        >
          {LINE_WIDTHS.map((lw) => (
            <option key={lw.label} value={lw.value}>
              {lw.label}
            </option>
          ))}
        </select>

        {/* Line Type */}
        <select
          value={lineType}
          onChange={(e) => setLineType(e.target.value)}
          className="px-2 py-1 border rounded bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200"
        >
          {LINE_TYPES.map((lt) => (
            <option key={lt} value={lt}>
              {lt}
            </option>
          ))}
        </select>

        <button
          onClick={handleClear}
          className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
        >
          Clear
        </button>

        <button
          onClick={handleAnalyzeClick}
          disabled={isAnalyzing}
          className="ml-auto px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:opacity-50"
        >
          Analyze
        </button>
      </div>

      {/* Math symbols as draggable elements */}
      <div className="flex gap-2 p-2 bg-gray-200 dark:bg-gray-800 border-b border-gray-300 dark:border-gray-700 flex-wrap">
        {MATH_SYMBOLS.map((s) => (
          <div
            key={s}
            draggable
            onDragStart={(e) => {
              e.dataTransfer.setData("symbol", s);
              // Optional: visual feedback
              e.currentTarget.classList.add("scale-125", "shadow-lg");
            }}
            onDragEnd={(e) => {
              e.currentTarget.classList.remove("scale-125", "shadow-lg");
            }}
            className="px-2 py-1 border rounded bg-white dark:bg-gray-900 cursor-grab hover:bg-gray-300 dark:hover:bg-gray-700 transition-transform transform duration-150"
          >
            {s}
          </div>
        ))}
      </div>

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        className="flex-1 border border-gray-300 dark:border-gray-700 cursor-crosshair touch-none"
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={stopDrawing}
        onDrop={(e) => {
          e.preventDefault();
          const symbol = e.dataTransfer.getData("symbol");
          if (symbol) handleDropSymbol(symbol, e);
        }}
        onDragOver={(e) => e.preventDefault()}
      />
    </div>
  );
}
